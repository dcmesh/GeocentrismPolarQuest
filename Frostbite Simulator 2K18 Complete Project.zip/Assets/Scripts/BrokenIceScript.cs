﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BrokenIceScript : MonoBehaviour
{

    public Sprite Water;
    public bool isWalkedOn = false;

    private SpriteRenderer spriteRenderer;
    // Use this for initialization

    void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    public void damageCrackedIce(bool steppedOn)
    {
        isWalkedOn = steppedOn;
        if (isWalkedOn)
            spriteRenderer.sprite = Water;
    }
}