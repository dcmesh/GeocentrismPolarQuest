﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IceWall : MonoBehaviour
{

    public Sprite snowfiller;   // Snow fill sprite
    public int hp = 1;          // HP of Ice wall
    bool hasPick;

    private SpriteRenderer spriteRenderer;
    private BoxCollider2D boxCollider2D;
    // Use this for initialization

    void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        boxCollider2D = GetComponent<BoxCollider2D>();
    }

    // Damages and deletes Ice Wall if hp gets low enough
    public void damageIce(int steppedOn)
    {
        spriteRenderer.sprite = snowfiller;
        transform.localScale = new Vector3(3.15f, 3.15f, 1f);
        hp -= 1;
        if (hp <= 0)
        {
            Destroy(boxCollider2D);
        }
    }
}