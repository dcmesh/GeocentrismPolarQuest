﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollisionPrint : MonoBehaviour {

	// Use this for initialization
	void onColissionEnter (Collision collision) {
        Debug.Log("Collision called");
	}

    void onColissionStay(Collision collision)
    {
        Debug.Log("Collision occuring");
    }
    void onColissionExit(Collision collision)
    {
        Debug.Log("Collision exited");
    }
}
