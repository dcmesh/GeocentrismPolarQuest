﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Entity : MonoBehaviour {

    public float moveTime = 0.02f;
    public LayerMask collisionLayer;

    private BoxCollider2D collisionBox;
    private Rigidbody2D rb;
    private float speed;

	// Use this for initialization
	protected virtual void Start () {
        collisionBox = GetComponent<BoxCollider2D>();
        rb = GetComponent<Rigidbody2D>();
        speed = 1f / moveTime;
	}

    //Checks if a move can be executed
    protected bool Move(float xDir, float yDir, out RaycastHit2D hit)
    {
        //Store start position and calculated end position
        Vector2 start = transform.position;
        Vector2 end = start + new Vector2(xDir, yDir);

        
        collisionBox.enabled = false;                           //Disable the object's own collision box
        hit = Physics2D.Linecast(start, end, collisionLayer);  //make a line
        collisionBox.enabled = true;                           //Re-enable boxCollider after linecast

        //Check if anything was hit
        if (hit.transform == null)
        {
            StartCoroutine(SmoothMovement(end));     //make move if not collision
            return true;                             //move was successful
        }
        return false;
    }


    //moving units from one space to next
    protected IEnumerator SmoothMovement(Vector3 end)
    {
        float sqrRemainingDistance = (transform.position - end).sqrMagnitude;   //Calculate the remaining distance
        //while (sqrRemainingDistance > float.Epsilon)                            //While that distance is greater than a very small amount
        //{
            //Vector3 newPostion = Vector3.MoveTowards(rb.position, end, speed * Time.deltaTime);
            rb.MovePosition(end);
            //sqrRemainingDistance = (transform.position - end).sqrMagnitude;
            //Return and loop until sqrRemainingDistance is close enough to zero to end the function
            yield return null;
        //}
    }


    //The virtual keyword means AttemptMove can be overridden by inheriting classes using the override keyword.
    //AttemptMove takes a generic parameter T to specify the type of component we expect our unit to interact with if blocked (Player for Enemies, Wall for Player).
    protected virtual void AttemptMove<T>(float xDir, float yDir)
        where T : Component
    {
        //Tell if move results in collision
        RaycastHit2D hit;
        bool canMove = Move(xDir / 14, yDir / 14, out hit);

        if (hit.transform == null)
            return;

        //Get a component reference to the component of type T attached to the object that was hit
        T hitComponent = hit.transform.GetComponent<T>();

        //If canMove is false and hitComponent is not equal to null, meaning MovingObject is blocked and has hit something it can interact with.
        if (!canMove && hitComponent != null)
            OnCantMove(hitComponent);
    }


    //What the object does if it cannot move
    protected abstract void OnCantMove<T>(T component)
        where T : Component;
}
