﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Player : Entity {

    public int enemyDamage = 1;
    public int firstAidHeal = 20;
    public int money = 100;
    public bool iceSpikeBoots = false;
    public bool icePick = true;
    public float restartLevelDelay = 1f;
    public Animator animator;


    private int health = 100;
    public Text healthText;

    public int dataPoints = 0;
    public Text dataPointsText;

    // Use this for initialization
    protected override void Start () {
        animator = GetComponent<Animator>();
        health = GameManager.instance.playerHealthPoints;
        healthText.text = "Health: " + health;

        dataPoints = GameManager.instance.playerResearchPoints;
        dataPointsText.text = "Research Points: " + dataPoints;
        base.Start();
	}

    private void OnDisable()
    {
        GameManager.instance.playerHealthPoints = health;
    }

    private void CheckIfGameOver()
    {
        if (health == 0)
            GameManager.instance.GameOver();
    }

    protected override void AttemptMove<T>(float xDir, float yDir)
    {
        int rand = Random.Range(1, health);
        if(rand == 1)
            health--;
        healthText.text = "Health" + health;
        base.AttemptMove<T>(xDir, yDir);
        CheckIfGameOver();
        GameManager.instance.playersTurn = false;
    }

    // Update is called once per frame
    void Update () {
        if (!GameManager.instance.playersTurn) return;

        int horizontal = 0;
        int vertical = 0;

        horizontal = (int) Input.GetAxisRaw("Horizontal");
        vertical = (int) Input.GetAxisRaw("Vertical");

        animator.SetFloat("speed", Mathf.Abs(horizontal) + Mathf.Abs(vertical));
        if (horizontal != 0 || vertical != 0)
            AttemptMove<IceWall>(horizontal, vertical);
        GameManager.instance.playersTurn = true;

    }


    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.tag == "Exit")
        {
            Invoke("Restart", restartLevelDelay);
            enabled = false;
        }
        else if (collision.tag == "FirstAid")
        {
            health += firstAidHeal;
            healthText.text = "+" + firstAidHeal + "Health" + health;
            collision.gameObject.SetActive(false);
        }
        else if(collision.tag == "Animal")
        {
            dataPoints++;
            dataPointsText.text = "+" + 1 + " Research Points" + dataPoints;
        }
    }
    protected override void OnCantMove<T>(T component)
    {
        if (icePick)
        {
            IceWall hitWall = component as IceWall;
            hitWall.damageIce(1);
        }
    }

    private void Restart()
    {
        SceneManager.LoadScene(0);
    }

    public void LoseHealth(int loss)
    {
        health -= loss;
        healthText.text = "-" + loss + "Health" + health;
        CheckIfGameOver();
    }
}
