﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CrackedIceScript : MonoBehaviour
{

    public Sprite crackedIceSprite;

    private SpriteRenderer spriteRenderer;
    private BoxCollider2D boxCollider2D;
    // Use this for initialization

    void Awake ()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        boxCollider2D = GetComponent<BoxCollider2D>();
    }

    public void damageCrackIce()
    {
        spriteRenderer.sprite = crackedIceSprite;
        transform.localScale = new Vector3(3.15f, 3.15f, 1f);
        Destroy(boxCollider2D);
    }
}
