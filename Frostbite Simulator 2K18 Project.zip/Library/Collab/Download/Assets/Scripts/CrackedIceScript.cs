﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CrackedIceScript : MonoBehaviour
{

    public Sprite crackedIceSprite;
    public bool isWalkedOn = false;

    private SpriteRenderer spriteRenderer;
	// Use this for initialization

	void Awake ()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
	}
	
	public void damageIce(bool steppedOn)
    {
        isWalkedOn = steppedOn;
        if (isWalkedOn)
            spriteRenderer.sprite = crackedIceSprite;
    }
}
